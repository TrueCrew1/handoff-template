TRUE CREW SHIFT HANDOVER EXPORT PACKAGE

Included files:
1. true-crew-shift-handover-v5-branded.html -> latest branded HTML lead magnet app
2. True_Crew_Shift_Handover_Template.xlsx -> spreadsheet template
3. Shift_Handover_Template.csv -> CSV sample/export structure
4. TrueCrew_Logo_1200x630.jpeg -> provided logo asset

Recommended primary asset for lead magnet delivery:
- Use the branded HTML app as the premium-feeling downloadable tool.
- Use the XLSX as the spreadsheet option for users who prefer Excel/Sheets workflows.

Branding notes:
- HTML app includes True Crew branding, contact email, website, upsell hints, and export naming.
- Spreadsheet can be further hardened with protected ranges in Google Sheets or Excel.
